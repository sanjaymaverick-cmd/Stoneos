# DPR Updater Sampler

This is a safe test version. It never edits the source files under `Test Input`.

## Test it

1. Place DPR files in `DPR Inbox`.
2. Keep the original master workbooks in `Test Input`.
3. Double-click `Run DPR Updater.cmd`.
4. Read `last-run.txt`.
5. Open the updated VEDAM files in `Test Output` and compare them with the originals.

## Five-factory setup

`factories.json` contains separate production and yearly workbooks for VEDAM, JSB, SG, FACTORY4 and FACTORY5. Replace the placeholder filenames with the actual files when they are ready. If a factory’s layout differs, add its own mapping before enabling it.

## Safety

- Do not place a master workbook in `DPR Inbox`.
- Keep the master workbooks closed while processing DPRs.
- A same factory/date DPR is skipped after it has been logged.
- A file that cannot be processed is reported in `last-run.txt`; it is not written into a master workbook.
