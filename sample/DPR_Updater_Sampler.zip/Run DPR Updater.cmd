@echo off
cd /d "%~dp0"
if not exist "node_modules" (
  if exist "C:\Users\BHAGWAN\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules" (
    mklink /J "node_modules" "C:\Users\BHAGWAN\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules" >nul
  )
)
if not exist "node_modules" (
  echo Required spreadsheet components were not found on this laptop.
  echo Open this folder in Codex and ask it to set up the DPR Updater.
  pause
  exit /b 1
)
node dpr-updater.mjs
pause
