import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const root = path.resolve(process.cwd());
const paths = {
  inbox: path.join(root, "DPR Inbox"),
  processed: path.join(root, "Processed DPRs"),
  review: path.join(root, "Needs Review"),
  output: path.join(root, "Test Output"),
  log: path.join(root, "processed-log.json"),
  config: path.join(root, "factories.json"),
};

const expenseOffset = {
  "block transport": 7, "block royalty": 8, "block purchase": 9,
  "epoxy,bati,segment": 10, "maintaince": 11, "construction": 12,
  "contactor": 13, "nexon ev": 14, "bike": 15, "mess": 16,
  "mobile": 17, "official": 18, "comm/ discount": 20,
  "medical": 21, "staff payment": 22, "misc.": 24,
};

const asNumber = (value) => typeof value === "number" && Number.isFinite(value) ? value : 0;
const cleanLabel = (value) => String(value ?? "").trim().toLowerCase();
const cellValue = (sheet, row, col) => sheet.getRangeByIndexes(row, col, 1, 1).values?.[0]?.[0] ?? null;
const put = (sheet, row, col, value) => { sheet.getRangeByIndexes(row, col, 1, 1).values = [[value]]; };
const localDateKey = (date) => [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");

function parseDateFromName(fileName) {
  const match = fileName.match(/DPR\s+(.+?)\s+(\d{1,2})\s+([A-Z]+)\s+(\d{4})/i);
  if (!match) throw new Error("Filename must be like: DPR VEDAM 10 JULY 2026.xlsx");
  const [, factory, dayText, monthText, yearText] = match;
  const month = { JANUARY: 0, FEBRUARY: 1, MARCH: 2, APRIL: 3, MAY: 4, JUNE: 5, JULY: 6, AUGUST: 7, SEPTEMBER: 8, OCTOBER: 9, NOVEMBER: 10, DECEMBER: 11 }[monthText.toUpperCase()];
  if (month === undefined) throw new Error(`Month '${monthText}' was not recognised.`);
  return { factory: factory.trim().toUpperCase(), date: new Date(Number(yearText), month, Number(dayText)), day: Number(dayText) };
}

function parseHours(note) {
  const text = String(note ?? "").toUpperCase();
  const hours = Number(text.match(/(\d+(?:\.\d+)?)\s*HRS?/)?.[1] ?? 0);
  const minutes = Number(text.match(/(\d+(?:\.\d+)?)\s*MNT/)?.[1] ?? 0);
  return hours + minutes / 60;
}

async function importWorkbook(filePath) {
  return SpreadsheetFile.importXlsx(await FileBlob.load(filePath));
}

async function readDpr(filePath) {
  const workbook = await importWorkbook(filePath);
  const sheet = workbook.worksheets.getItemAt(0);
  const rows = sheet.getRange("A1:B28").values;
  const lookup = new Map(rows.map((row) => [cleanLabel(row[0]), row[1]]));
  const grinding = asNumber(lookup.get("lpm granding"));
  const polishing = asNumber(lookup.get("lpm polishung"));
  const expenses = {};
  for (const [label, offset] of Object.entries(expenseOffset)) expenses[offset] = asNumber(lookup.get(label));
  const saleAmount = asNumber(lookup.get("sales descripition")) + asNumber(lookup.get("tax recived"));
  return {
    multi: asNumber(lookup.get("multy")),
    lpmGrinding: grinding,
    lpmPolishing: polishing,
    lpmTotal: grinding + polishing,
    runningHours: parseHours(lookup.get("note")),
    saleQty: asNumber(lookup.get("total sale")),
    saleAmount,
    expenses,
  };
}

function financialMonthIndex(date) {
  return (date.getMonth() + 9) % 12; // April = 0, March = 11
}

function productionStartColumn(date) { return financialMonthIndex(date) * 28; }
function productionRow(date) { return date.getDate() + 1; } // Excel row 3 is day 1; zero-based row 2

function writeDailyProduction(sheet, date, data) {
  const start = productionStartColumn(date);
  const row = productionRow(date);
  put(sheet, row, start + 1, data.multi);
  put(sheet, row, start + 2, data.lpmTotal);
  put(sheet, row, start + 3, data.runningHours);
  put(sheet, row, start + 4, data.saleQty);
  put(sheet, row, start + 5, data.saleAmount);
  for (const [offset, value] of Object.entries(data.expenses)) put(sheet, row, start + Number(offset), value || null);
}

function updateYearlyMonth(productionSheet, yearlySheet, date) {
  const start = productionStartColumn(date);
  const rowStart = 2;
  const rowEnd = 32;
  const sumDaily = (offset) => {
    let total = 0;
    for (let row = rowStart; row <= rowEnd; row++) total += asNumber(cellValue(productionSheet, row, start + offset));
    return total;
  };
  const totalExpenses = () => {
    let total = 0;
    for (let row = rowStart; row <= rowEnd; row++) {
      for (let offset = 7; offset <= 25; offset++) total += asNumber(cellValue(productionSheet, row, start + offset));
    }
    return total;
  };
  const annualRow = 4 + financialMonthIndex(date);
  const outputs = [sumDaily(1), sumDaily(2), sumDaily(3), null, sumDaily(4), sumDaily(5), totalExpenses(), sumDaily(7), sumDaily(8), sumDaily(9), sumDaily(10), sumDaily(11), sumDaily(12), sumDaily(13), sumDaily(14)];
  outputs.forEach((value, index) => { if (value !== null) put(yearlySheet, annualRow, index + 1, value); });
}

async function saveWorkbook(workbook, filePath) {
  const output = await SpreadsheetFile.exportXlsx(workbook);
  await output.save(filePath);
}

async function loadLog() {
  try { return JSON.parse(await fs.readFile(paths.log, "utf8")); } catch { return []; }
}

async function main() {
  const config = JSON.parse(await fs.readFile(paths.config, "utf8"));
  const log = await loadLog();
  const files = (await fs.readdir(paths.inbox)).filter((file) => /\.xlsx$/i.test(file));
  const report = [];
  const loadedFactories = new Map();
  for (const file of files) {
    try {
      const target = parseDateFromName(file);
      const factory = config.factories[target.factory];
      if (!factory) throw new Error(`Factory '${target.factory}' is not configured.`);
      const key = `${target.factory}|${localDateKey(target.date)}`;
      if (log.some((item) => item.key === key)) { report.push(`SKIPPED (duplicate): ${file}`); continue; }
      const productionPath = path.join(root, factory.productionWorkbook);
      const yearlyPath = path.join(root, factory.yearlyWorkbook);
      await fs.access(productionPath); await fs.access(yearlyPath);
      const data = await readDpr(path.join(paths.inbox, file));
      let loaded = loadedFactories.get(target.factory);
      if (!loaded) {
        const production = await importWorkbook(productionPath);
        const yearly = await importWorkbook(yearlyPath);
        loaded = {
          factory, production, yearly,
          productionSheet: production.worksheets.getItem(factory.productionSheet),
          yearlySheet: yearly.worksheets.getItem(factory.yearlySheet),
        };
        loadedFactories.set(target.factory, loaded);
      }
      writeDailyProduction(loaded.productionSheet, target.date, data);
      updateYearlyMonth(loaded.productionSheet, loaded.yearlySheet, target.date);
      await fs.copyFile(path.join(paths.inbox, file), path.join(paths.processed, file));
      log.push({ key, factory: target.factory, date: localDateKey(target.date), sourceFile: file, processedAt: new Date().toISOString() });
      report.push(`PROCESSED: ${file}`);
    } catch (error) {
      report.push(`NEEDS REVIEW: ${file} — ${error.message}`);
    }
  }
  for (const [factoryName, loaded] of loadedFactories) {
    await saveWorkbook(loaded.production, path.join(paths.output, `${factoryName} Production Master - updated.xlsx`));
    await saveWorkbook(loaded.yearly, path.join(paths.output, `${factoryName} Yearly Data - updated.xlsx`));
  }
  await fs.writeFile(paths.log, JSON.stringify(log, null, 2));
  await fs.writeFile(path.join(root, "last-run.txt"), report.join("\n") || "No DPR files found in DPR Inbox.");
  console.log(report.join("\n") || "No DPR files found in DPR Inbox.");
}

await main();
